package co.jero.domain;

import java.util.List;

public class Inventario {
    private int codigo;
    private String nombre;
    private List<Existencia> UnidadesDisponiblesPorMateriaPrima;


    public void IngresarNuevaMateriaPrima(MateriaPrima materiaPrima){

    }
    public void EliminarMateriaPrima(MateriaPrima materiaPrima){

    }
    public void UtilizarMateriaPrima(MateriaPrima materiaPrima,Producto producto){

    }
    public void ReponerNuevaMateriaPrima(MateriaPrima materiaPrima){

    }
}
