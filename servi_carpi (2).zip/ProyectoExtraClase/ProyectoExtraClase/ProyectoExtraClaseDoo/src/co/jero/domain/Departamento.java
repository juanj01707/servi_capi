package co.jero.domain;

public class Departamento {
    private int codigo;
    private String nombre;
    private Pais pais;
}
