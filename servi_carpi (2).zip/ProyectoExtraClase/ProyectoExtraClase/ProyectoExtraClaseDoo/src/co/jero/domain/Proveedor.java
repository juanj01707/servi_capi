package co.jero.domain;

public class Proveedor {
    private int codigo;
    private String nombre;
    private String nit;

}
