package co.jero.domain;

public class TipoIdentificacion {
    private int codigo;
    private String nombre;
}
