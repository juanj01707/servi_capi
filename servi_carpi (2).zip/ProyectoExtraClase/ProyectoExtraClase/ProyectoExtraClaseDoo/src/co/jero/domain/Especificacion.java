package co.jero.domain;

public class Especificacion {
    private int codigo;
    private String nombre;
    private String unidadDeMedida;
    private String formato;
    private int calibreOAcnchura;
    private String marca;
    private String acabado;
    private String material;

}
