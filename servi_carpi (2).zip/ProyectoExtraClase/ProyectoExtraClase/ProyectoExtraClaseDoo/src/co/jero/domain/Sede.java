package co.jero.domain;

import java.util.List;

public class Sede {
    private int codigo;
    private String nombre;
    private Ciudad ciudad;
    private Inventario inventario;
    private String direccion;
    private Empresa empresa;
    private List<Empleado> empleados;

    public void contratarEmpleado(Empleado empleado) {

    }
    public void DespedirEmpleado(Empleado empleado) {

    }

}
