package co.jero.domain;

public class Venta {
    private int codigo;
    private String nombre;
    private Pedido pedido;
}
