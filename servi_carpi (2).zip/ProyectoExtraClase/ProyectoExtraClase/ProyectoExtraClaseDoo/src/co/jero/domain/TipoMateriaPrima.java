package co.jero.domain;

public class TipoMateriaPrima {
    private int codigo;
    private String nombre;
}
