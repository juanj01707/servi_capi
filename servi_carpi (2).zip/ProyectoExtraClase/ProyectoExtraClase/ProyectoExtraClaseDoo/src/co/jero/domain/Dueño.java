package co.jero.domain;

public class Dueño extends Persona{
}
