package co.jero.domain;

import java.util.Date;

public class Pedido {
    private int codigo;
    private String nombre;
    private Date fechaEntrega;
    private EstadoPedido estadoPedido;

    public void AplazarPedido(Pedido pedido){

    }

    public void AcortarTiempoDelPedido(Pedido pedido){

    }

}
