package co.jero.domain;

public class MateriaPrima {
    private int codigo;
    private String nombre;
    private String Descripcion;
    private int valor;
    private Especificacion especificacion;
    private TipoMateriaPrima tipoMateriaPrima;

}
