package co.jero.domain;

public class EstadoEmpleado {
    private int codigo;
    private String nombre;
}
