package co.jero.domain;

public class ProoveedorPorMateriaPrima {
    private int codigo;
    private String nombre;
    private MateriaPrima materiaPrima;
    private Proveedor proveedor;
    private int valorPorUnidad;

}
