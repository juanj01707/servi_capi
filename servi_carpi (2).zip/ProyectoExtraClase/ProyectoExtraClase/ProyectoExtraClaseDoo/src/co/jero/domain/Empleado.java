package co.jero.domain;

public class Empleado extends Persona{
    private TipoEmpleado tipoEmpleado;
    private EstadoEmpleado estadoEmpleado;
    private Sede sede;

}
