package co.jero.domain;

import java.util.List;

public class Producto {
    private int codigo;
    private String nombre;
    private Venta venta;
    private List<MateriaPrima>materiaPrimasATrabajar;

    public void SolicitarMateriaPrima(List<MateriaPrima>materiaPrimasATrabajar){

    }

}
