package co.jero.domain;

import java.util.List;

public class MateriaPrimaPorProducto {
    private int codigo;
    private String nombre;
    private Producto producto;
    private List<MateriaPrima> materiaPrimas;


}
