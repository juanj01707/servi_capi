package co.jero.domain;

public class Existencia {
    private int codigo;
    private String nombre;
    private int unidades;
    private MateriaPrima materiaPrima;
}
