package co.jero.domain;

public class TipoCotizacion {
    private int codigo;
    private String nombre;
    private int valorPorMetroMadecor;
    private String detalles;


}
