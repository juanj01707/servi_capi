package co.jero.domain;

import java.util.List;

public class Cliente {
    private List<Cotizacion> cotizaciones;

    public void ComprarCotizacion(Cotizacion cotizacion){

    }
    public void ModificarCotizacion(Cotizacion cotizacion){

    }

}
