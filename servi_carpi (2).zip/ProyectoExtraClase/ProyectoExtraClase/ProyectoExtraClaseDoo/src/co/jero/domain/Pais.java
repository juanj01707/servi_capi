package co.jero.domain;

public class Pais {
    private int codigo;
    private String nombre;
}
