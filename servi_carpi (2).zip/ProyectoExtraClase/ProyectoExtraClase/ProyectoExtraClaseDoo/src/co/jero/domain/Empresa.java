package co.jero.domain;

public class Empresa {
    private int codigo;
    private String nombre;
    private Dueño dueño;
    private String nit;

}
