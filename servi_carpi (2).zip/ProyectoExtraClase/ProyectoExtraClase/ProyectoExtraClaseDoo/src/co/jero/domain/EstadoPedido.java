package co.jero.domain;

public class EstadoPedido {
    private int codigo;
    private String nombre;
}
