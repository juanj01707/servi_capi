package co.jero.domain;

public class Persona {
    protected int codigo;
    protected String nombre;
    protected String identificacion;
    protected TipoIdentificacion tipoIdentificacion;


}
