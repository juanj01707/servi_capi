package co.jero.domain;

public class TipoEmpleado {
    private int codigo;
    private String nombre;
    private int salario;
    private String funcion;

}
