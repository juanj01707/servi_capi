package co.jero.domain;

public class Ciudad {
    private int codigo;
    private String nombre;
    private Departamento departamento;

}
