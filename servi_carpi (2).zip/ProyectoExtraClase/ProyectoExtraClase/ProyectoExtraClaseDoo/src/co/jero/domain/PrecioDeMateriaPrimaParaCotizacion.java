package co.jero.domain;

import java.util.List;

public class PrecioDeMateriaPrimaParaCotizacion {
    private int codigo;
    private String nombre;
    private Cotizacion cotizacion;
    private MateriaPrima materiaPrima;
    private List<Integer> listaDePreciosDeMateriasSolicitadas;




}
